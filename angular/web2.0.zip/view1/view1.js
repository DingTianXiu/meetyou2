'use strict';

angular.module('myApp.view1', ['ngRoute'])

.controller('View1Ctrl', [function() {

}])
;