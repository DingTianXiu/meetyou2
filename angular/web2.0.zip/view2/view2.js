'use strict';

angular.module('myApp.view2', ['ngRoute'])


.controller('View2Ctrl', function($scope) {
 $scope.aa=2;
});